package main

import (
	"ProjectWIND/wba"
	"log"
)

// AppInit 该函数用于初始化应用信息, 并定义方法
func AppInit() wba.AppInfo {
	// 写入应用信息
	app := wba.NewApp(
		wba.WithName("app_demo"),                           // 应用名称
		wba.WithAuthor("WIND"),                             // 作者
		wba.WithVersion("1.0.0"),                           // 版本
		wba.WithDescription("This is a demo application"),  // 应用描述
		wba.WithNamespace("app_demo"),                      // 命名空间, 私有数据库请使用应用的名称, 公共数据库请使用"PUBLIC"
		wba.WithWebUrl("https://github.com/wind/app_demo"), // 应用主页
		wba.WithLicense("MIT"),                             // 应用许可证
	)

	// 定义命令
	cmdTest := wba.NewCmd(
		//命令名称
		"app",
		//命令介绍
		"插件测试",
		func(args []string, msg wba.MessageEventInfo) {
			val := args[0]
			log.Println("app_demo cmdTest", val)
			switch val {
			case "help":
				{
					wba.Wind.SendMsg(msg, "app_demo help", false)
				}
			default:
				{
					wba.Wind.SendMsg(msg, "Hello, wind app!", false)
					return
				}
			}
		},
	)

	// 将命令添加到应用命令列表中
	app.AddCmd("app", cmdTest)

	return app
}

// Application 向核心暴露的应用接口,标识符为Application, 不可修改
var Application = AppInit()

func main() {
}
